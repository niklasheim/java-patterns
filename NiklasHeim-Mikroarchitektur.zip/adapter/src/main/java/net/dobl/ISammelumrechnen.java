package net.dobl;

public interface ISammelumrechnen {
    public double sammelumrechnen(String variante, double[] betraege);
}
