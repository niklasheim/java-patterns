package net.dobl;

public interface IUmrechnen {
    public double umrechnen();
}
