package net.dobl;

public interface IObs {
    public void update(Object o);
}
